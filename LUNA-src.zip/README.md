RPC Port: 38356
Network Port: 38353